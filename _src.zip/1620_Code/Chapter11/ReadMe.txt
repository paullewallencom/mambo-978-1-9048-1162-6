
The "zaksprings" folder contains Various sample scripts, and image files that are used in Chapter 11 of the Learning Mambo Book.

The "css" folder contains the "template_css file" required for this chapter.
 
The "index.php" and "templateDetails.xml" are the other main files required for this chapter.

The "template_thumbnail.png","img_header.jpeg", "bg_inside.jpeg", "background.jpeg", and "readon.png" are the image files that are used in this Chapter.


This folder contains Various sample scripts, and image files that are used in Chapter 8 of the Learning Mambo Book.

The "StuffForChapter8.zip" folder contains the scripts required for this chapter. 

The "backnine_beast.png" is an image file that is used in this Chapter.

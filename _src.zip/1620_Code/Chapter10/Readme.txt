This folder contains zip file called "holes.zip". This has three image files that are required in chapter 10. 

